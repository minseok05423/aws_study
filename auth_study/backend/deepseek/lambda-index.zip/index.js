export const handler = async (event, context) => {
  try {
    console.log("Lambda started");
    console.log("Event body:", event.body);
    console.log("API key exists:", !!process.env.DEEPSEEK_API_KEY);

    // Parse request body
    let request;
    try {
      if (!event.body) {
        console.log("event.body is:", event.body);
        throw new Error("Request body is missing");
      }
      const body = JSON.parse(event.body);
      if (!body.query || body.query === "") {
        throw new Error("no queries provided");
      }
      request = body.query;
      console.log("Parsed query:", request);
    } catch (error) {
      console.log("parsing error", error);
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          message: `error during request parsing: ${error.message}`,
        }),
      };
    }

    // Call Deepseek API with fetch
    try {
      console.log("Calling Deepseek API...");

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 20000);

      const response = await fetch("https://api.deepseek.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.DEEPSEEK_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "deepseek-chat",
          messages: [{ role: "user", content: request }],
          max_tokens: 50,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);
      console.log("Deepseek responded with status:", response.status);

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Deepseek API error ${response.status}: ${errorText}`);
      }

      const completion = await response.json();
      console.log("Response:", completion.choices[0].message.content);

      return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify(completion),
      };
    } catch (error) {
      console.error("Deepseek API error:", error);
      return {
        statusCode: 500,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          message: `deepseek error has occurred: ${error.message}`,
        }),
      };
    }
  } catch (fatalError) {
    console.error("Fatal error in Lambda:", fatalError);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        message: `Fatal error: ${fatalError.message}`,
      }),
    };
  }
};
